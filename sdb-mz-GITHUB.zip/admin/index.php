<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Painel Administrativo - Dashboard Principal (admin/index.php)
 */

require_once '../includes/config.php';
require_once '../includes/functions.php';

// Garantir que utilizador está de facto autenticado como Admin
verificarAutenticacao();

$admin_nome = $_SESSION['admin_nome'];

// 1. FUNCIONALIDADE: EXPORTAR RELATÓRIO EM CSV
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    // Definir cabeçalhos HTTP para download direto do ficheiro
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="SDB_MZ_Relatorio_Denuncias_' . date('Ymd_His') . '.csv"');
    
    // Abrir stream de escrita
    $output = fopen('php://output', 'w');
    
    // Adicionar BOM para suporte do Excel com caracteres acentuados (UTF-8)
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Cabeçalho das colunas do CSV
    fputcsv($output, [
        'ID', 
        'Código Rastreio', 
        'Tipo de Burla', 
        'Descrição', 
        'Número Suspeito', 
        'Valor Envolvido (MZN)', 
        'Data do Incidente', 
        'Email Denunciante', 
        'Estado', 
        'IP de Origem', 
        'Data Criação'
    ]);
    
    try {
        $stmt_export = $pdo->query("SELECT * FROM denuncias ORDER BY data_criacao DESC");
        while ($row = $stmt_export->fetch()) {
            fputcsv($output, [
                $row['id'],
                $row['codigo_rastreio'],
                $row['tipo_burla'],
                $row['descricao'],
                $row['numero_suspeito'],
                $row['valor_envolvido'],
                $row['data_incidente'],
                $row['email_denunciante'] ?: 'Anónimo',
                $row['estado'],
                $row['ip_origem'],
                $row['data_criacao']
            ]);
        }
    } catch (PDOException $e) {
        // Ignora silenciado
    }
    
    fclose($output);
    exit();
}

// 2. RECUPERAR METRICAS DENSAS PARA OS CARDS DO DASHBOARD
try {
    // Total Denúncias
    $total_denuncias = $pdo->query("SELECT COUNT(*) FROM denuncias")->fetchColumn();
    
    // Total por estados
    $total_analise = $pdo->query("SELECT COUNT(*) FROM denuncias WHERE estado = 'Em Análise'")->fetchColumn();
    $total_investigando = $pdo->query("SELECT COUNT(*) FROM denuncias WHERE estado = 'Em Investigação'")->fetchColumn();
    $total_resolvidas = $pdo->query("SELECT COUNT(*) FROM denuncias WHERE estado = 'Resolvida'")->fetchColumn();
    $total_rejeitadas = $pdo->query("SELECT COUNT(*) FROM denuncias WHERE estado = 'Rejeitada'")->fetchColumn();
    
    // Total perdas financeiras em MZN
    $total_perdas = $pdo->query("SELECT SUM(valor_envolvido) FROM denuncias")->fetchColumn() ?: 0.00;
    
    // Alertas ativos
    $total_alertas_ativos = $pdo->query("SELECT COUNT(*) FROM alertas WHERE ativo = 1")->fetchColumn();
} catch (PDOException $e) {
    // Fallbacks para o caso do setup db ainda não ter corrido
    $total_denuncias = 3; $total_analise = 1; $total_investigando = 1; $total_resolvidas = 1; $total_rejeitadas = 0; $total_perdas = 8500.00; $total_alertas_ativos = 2;
}

// 3. CAPTURAR FILTROS DA PESQUISA
$filtro_tipo = filter_input(INPUT_GET, 'filtro_tipo', FILTER_DEFAULT) ?: '';
$filtro_estado = filter_input(INPUT_GET, 'filtro_estado', FILTER_DEFAULT) ?: '';
$pesquisa_termo = filter_input(INPUT_GET, 'pesquisa', FILTER_DEFAULT) ?: '';

// Construir Query Dinâmica com filtros
$sql_query = "SELECT * FROM denuncias WHERE 1=1";
$params = [];

if ($filtro_tipo !== '') {
    $sql_query .= " AND tipo_burla = ?";
    $params[] = $filtro_tipo;
}

if ($filtro_estado !== '') {
    $sql_query .= " AND estado = ?";
    $params[] = $filtro_estado;
}

if ($pesquisa_termo !== '') {
    $sql_query .= " AND (codigo_rastreio LIKE ? OR numero_suspeito LIKE ? OR descricao LIKE ? OR email_denunciante LIKE ?)";
    $termo_match = "%" . $pesquisa_termo . "%";
    $params[] = $termo_match;
    $params[] = $termo_match;
    $params[] = $termo_match;
    $params[] = $termo_match;
}

// Ordenação default por registos mais recentes
$sql_query .= " ORDER BY data_criacao DESC";

try {
    $stmt_lista = $pdo->prepare($sql_query);
    $stmt_lista->execute($params);
    $denuncias_lista = $stmt_lista->fetchAll();
} catch (PDOException $e) {
    $denuncias_lista = [];
}

// Obter os números de telefone suspeitos mais reportados (ranking de fraude)
try {
    $stmt_ranking = $pdo->query("
        SELECT numero_suspeito, COUNT(*) as ocorrencias, tipo_burla, MAX(data_criacao) as ultimo_caso 
        FROM denuncias 
        WHERE numero_suspeito IS NOT NULL AND numero_suspeito != '' 
        GROUP BY numero_suspeito 
        ORDER BY ocorrencias DESC 
        LIMIT 5
    ");
    $suspeitos_ranking = $stmt_ranking->fetchAll();
} catch (PDOException $e) {
    $suspeitos_ranking = [];
}
?>
<!DOCTYPE html>
<html lang="pt-MZ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDB-MZ - Admin Dashboard</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Font Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

    <!-- Flag accent -->
    <div class="flag-ribbon"></div>

    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
        <div class="container-fluid px-md-5">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="p-2 me-2 bg-moz-green text-white rounded font-weight-bold d-inline-flex align-items-center" style="height:34px">
                    <i class="fas fa-lock text-moz-yellow me-2"></i> SDB-MZ Admin
                </span>
                <span class="text-white-50 small d-none d-md-inline">Painel de Controlo</span>
            </a>
            
            <div class="d-flex align-items-center gap-3">
                <span class="text-white-50 d-none d-md-inline small"><i class="far fa-user me-1 text-moz-yellow"></i> Olá, <strong><?php echo htmlspecialchars($admin_nome); ?></strong></span>
                <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-pill px-3"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <!-- Sub Navbar Tab Selector -->
    <div class="bg-white border-bottom shadow-sm">
        <div class="container-fluid px-md-5 py-2 d-flex flex-wrap justify-content-between align-items-center">
            <div class="d-flex gap-2">
                <a href="index.php" class="btn btn-dark btn-sm rounded px-3 active"><i class="fas fa-chart-line me-2 text-moz-yellow"></i>Dashboard Geral</a>
                <a href="alertas.php" class="btn btn-outline-dark btn-sm rounded px-3"><i class="fas fa-bullhorn me-2 text-danger"></i>Gerir Alertas Públicos</a>
                <a href="../index.php" target="_blank" class="btn btn-link btn-sm text-decoration-none text-muted"><i class="fas fa-external-link-alt me-1"></i>Ver Portal Público</a>
            </div>
            <div class="mt-2 mt-md-0">
                <a href="index.php?export=csv" class="btn btn-success bg-moz-green border-0 btn-sm text-white fw-bold shadow-sm px-3"><i class="fas fa-file-excel me-2"></i>EXPORTAR RELATÓRIO CSV</a>
            </div>
        </div>
    </div>

    <!-- Main Admin Layout Dashboard -->
    <main class="py-5">
        <div class="container-fluid px-md-5">

            <!-- Cards de Métricas Rápidas -->
            <div class="row g-3 mb-5">
                
                <!-- Card 1: Total -->
                <div class="col-sm-6 col-lg-3">
                    <div class="card admin-card border-0 bg-white p-4 h-100">
                        <span class="text-muted text-uppercase font-monospace text-xs mb-1 d-block" style="font-size: 0.75rem; letter-spacing:0.5px">TOTAL DENÚNCIAS</span>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <h2 class="fw-bold text-dark mb-0"><?php echo htmlspecialchars($total_denuncias); ?></h2>
                            <span class="p-3 bg-primary bg-opacity-10 text-primary rounded-circle"><i class="fas fa-envelope-open-text fa-lg"></i></span>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Em Analise (Novas) -->
                <div class="col-sm-6 col-lg-3">
                    <div class="card admin-card border-0 bg-white p-4 h-100" style="border-left: 4px solid #6c757d !important;">
                        <span class="text-muted text-uppercase font-monospace text-xs mb-1 d-block" style="font-size: 0.75rem; letter-spacing:0.5px">EM FILA (TRIAGEM)</span>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <h2 class="fw-bold text-secondary mb-0"><?php echo htmlspecialchars($total_analise); ?></h2>
                            <span class="p-3 bg-secondary bg-opacity-10 text-secondary rounded-circle"><i class="fas fa-clock fa-lg"></i></span>
                        </div>
                    </div>
                </div>

                <!-- Card 3: Resolvidos e Bloqueados -->
                <div class="col-sm-6 col-lg-3">
                    <div class="card admin-card border-0 bg-white p-4 h-100" style="border-left: 4px solid #198754 !important;">
                        <span class="text-muted text-uppercase font-monospace text-xs mb-1 d-block" style="font-size: 0.75rem; letter-spacing:0.5px">CASOS RESOLVIDOS</span>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <h2 class="fw-bold text-success mb-0"><?php echo htmlspecialchars($total_resolvidas); ?></h2>
                            <span class="p-3 bg-success bg-opacity-10 text-success rounded-circle"><i class="fas fa-check-double fa-lg"></i></span>
                        </div>
                    </div>
                </div>

                <!-- Card 4: Perdas Monetárias Acumuladas -->
                <div class="col-sm-6 col-lg-3">
                    <div class="card admin-card border-0 bg-white p-4 h-100" style="border-left: 4px solid #fcd116 !important;">
                        <span class="text-muted text-uppercase font-monospace text-xs mb-1 d-block" style="font-size: 0.75rem; letter-spacing:0.5px">MONTANTE GERAL DE BURLAS</span>
                        <div class="d-flex align-items-center justify-content-between mt-1">
                            <h3 class="fw-bold text-dark font-monospace mb-0 text-truncate" style="font-size: 1.25rem"><?php echo formatarMeticais($total_perdas); ?></h3>
                            <span class="p-3 bg-warning bg-opacity-10 text-warning rounded-circle" style="color: #6a4c00 !important;"><i class="fas fa-wallet fa-lg"></i></span>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Divisão Lateral: Lista de Casos (Esquerda 8) vs Ranking Telefones (Direita 4) -->
            <div class="row g-4">
                
                <!-- Coluna Esquerda: Listagem e Filtros -->
                <div class="col-xl-9 col-lg-8">
                    <div class="card admin-card border-0 bg-white p-4">
                        
                        <h5 class="fw-bold text-dark mb-4"><i class="fas fa-list-stars me-2 text-primary"></i>Filtros e Gestão de Denúncias</h5>

                        <!-- Linha de Pesquisa Avançada e Filtros -->
                        <form method="GET" action="index.php" class="row g-3 mb-4">
                            
                            <!-- Termo chave -->
                            <div class="col-md-4 col-sm-6">
                                <label for="pesquisa" class="form-label small fw-bold">Pesquisa de Chave</label>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text"><i class="fas fa-search"></i></span>
                                    <input type="text" class="form-control" id="pesquisa" name="pesquisa" value="<?php echo htmlspecialchars($pesquisa_termo); ?>" placeholder="ex: Código, nº suspeito, palavra...">
                                </div>
                            </div>
                            
                            <!-- Tipo burla -->
                            <div class="col-md-3 col-sm-6">
                                <label for="filtro_tipo" class="form-label small fw-bold">Tipo Burla</label>
                                <select class="form-select form-select-sm" id="filtro_tipo" name="filtro_tipo">
                                    <option value="" selected>Todos os tipos...</option>
                                    <option value="M-Pesa/E-Mola" <?php echo ($filtro_tipo === 'M-Pesa/E-Mola') ? 'selected' : ''; ?>>M-Pesa/E-Mola</option>
                                    <option value="Redes Sociais" <?php echo ($filtro_tipo === 'Redes Sociais') ? 'selected' : ''; ?>>Redes Sociais</option>
                                    <option value="Phishing" <?php echo ($filtro_tipo === 'Phishing') ? 'selected' : ''; ?>>Phishing</option>
                                    <option value="Falso Investimento" <?php echo ($filtro_tipo === 'Falso Investimento') ? 'selected' : ''; ?>>Falso Investimento</option>
                                    <option value="Comércio Online" <?php echo ($filtro_tipo === 'Comércio Online') ? 'selected' : ''; ?>>Comércio Online</option>
                                    <option value="Outro" <?php echo ($filtro_tipo === 'Outro') ? 'selected' : ''; ?>>Outro</option>
                                </select>
                            </div>

                            <!-- Estado do caso -->
                            <div class="col-md-3 col-sm-6">
                                <label for="filtro_estado" class="form-label small fw-bold">Estado Processo</label>
                                <select class="form-select form-select-sm" id="filtro_estado" name="filtro_estado">
                                    <option value="" selected>Todos os estados...</option>
                                    <option value="Em Análise" <?php echo ($filtro_estado === 'Em Análise') ? 'selected' : ''; ?>>Em Análise</option>
                                    <option value="Confirmada" <?php echo ($filtro_estado === 'Confirmada') ? 'selected' : ''; ?>>Confirmada</option>
                                    <option value="Em Investigação" <?php echo ($filtro_estado === 'Em Investigação') ? 'selected' : ''; ?>>Em Investigação</option>
                                    <option value="Resolvida" <?php echo ($filtro_estado === 'Resolvida') ? 'selected' : ''; ?>>Resolvida</option>
                                    <option value="Rejeitada" <?php echo ($filtro_estado === 'Rejeitada') ? 'selected' : ''; ?>>Rejeitada</option>
                                </select>
                            </div>

                            <!-- Botões de Filtros -->
                            <div class="col-md-2 col-sm-6 d-flex align-items-end gap-1">
                                <button type="submit" class="btn btn-dark btn-sm w-50 py-2"><i class="fas fa-filter"></i></button>
                                <a href="index.php" class="btn btn-outline-secondary btn-sm w-50 py-2" title="Limpar Filtros"><i class="fas fa-undo"></i></a>
                            </div>

                        </form>

                        <!-- Tabela Responsiva de Casos -->
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border">
                                <thead class="table-dark">
                                    <tr class="small text-uppercase">
                                        <th class="py-3 px-3">Código</th>
                                        <th class="py-3">Data Caso</th>
                                        <th class="py-3">Tipo</th>
                                        <th class="py-3">Suspeito</th>
                                        <th class="py-3 text-end">Prejuízo (MZN)</th>
                                        <th class="py-3 text-center">Estado</th>
                                        <th class="py-3 text-center">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($denuncias_lista)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center py-5 text-muted">
                                                <i class="far fa-folder-open fa-3x mb-3 d-block text-black-50"></i>
                                                Nenhuma denúncia cadastrada ou encontrada com os parâmetros configurados.
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($denuncias_lista as $item): ?>
                                            <tr class="small">
                                                <td class="px-3 font-monospace fw-bold text-dark"><?php echo htmlspecialchars($item['codigo_rastreio']); ?></td>
                                                <td><?php echo date('d/m/Y', strtotime($item['data_incidente'])); ?></td>
                                                <td class="fw-bold"><?php echo htmlspecialchars($item['tipo_burla']); ?></td>
                                                <td class="font-monospace fw-bold text-danger"><?php echo $item['numero_suspeito'] ? htmlspecialchars($item['numero_suspeito']) : '<span class="text-muted fw-normal">-</span>'; ?></td>
                                                <td class="text-end font-monospace fw-bold text-success"><?php echo number_format((float)$item['valor_envolvido'], 2, ',', '.'); ?></td>
                                                <td class="text-center">
                                                    <span class="badge <?php echo obterClasseEstado($item['estado']); ?> py-1.5 px-3 rounded-pill">
                                                        <?php echo htmlspecialchars($item['estado']); ?>
                                                    </span>
                                                </td>
                                                <td class="text-center">
                                                    <a href="denuncia.php?id=<?php echo (int)$item['id']; ?>" class="btn btn-outline-primary btn-sm rounded-circle" title="Analisar Detalhadamente" style="width: 30px; height: 30px; padding: 0; line-height: 28px;">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>

                <!-- Coluna Direita: Ranking de Números Suspeitos + Alertas Rápidos Link -->
                <div class="col-xl-3 col-lg-4">
                    
                    <!-- Ranking Numeros Suspeitos -->
                    <div class="card admin-card border-0 bg-white p-4 mb-4">
                        <h6 class="fw-bold text-dark mb-3"><i class="fas fa-skull text-danger me-2"></i>Ranking de Números Burlões</h6>
                        <p class="text-muted small">Números fraudulentos mais indicados ou repetitivos por múltiplos denunciantes anónimos.</p>
                        
                        <div class="list-group list-group-flush">
                            <?php if (empty($suspeitos_ranking)): ?>
                                <div class="text-center text-muted py-4 small">Nenhum número reportado com frequência no momento.</div>
                            <?php else: ?>
                                <?php foreach ($suspeitos_ranking as $rank): ?>
                                    <div class="list-group-item px-0 py-3 bg-transparent border-bottom">
                                        <div class="d-flex justify-content-between align-items-center mb-1">
                                            <span class="fw-bold text-dark font-monospace"><i class="fas fa-mobile-alt text-danger me-2"></i><?php echo htmlspecialchars($rank['numero_suspeito']); ?></span>
                                            <span class="badge bg-danger rounded-pill px-2 py-1 tiny" style="font-size: 0.75rem"><?php echo (int)$rank['ocorrencias']; ?> Denúncias</span>
                                        </div>
                                        <div class="d-flex justify-content-between text-muted" style="font-size: 0.75rem;">
                                            <span><?php echo htmlspecialchars($rank['tipo_burla']); ?></span>
                                            <span>Última: <?php echo date('d/m/Y', strtotime($rank['ultimo_caso'])); ?></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Informational Card -->
                    <div class="card admin-card border-0 bg-warning bg-opacity-10 p-4 border-start border-warning border-4 text-dark mb-4">
                        <h6 class="fw-bold mb-2 text-warning" style="color:#785700 !important"><i class="fas fa-user-shield me-2"></i>Conselho do SDB-MZ</h6>
                        <p class="small text-muted mb-0" style="line-height:1.6">
                            Para formalizar a cassação preventiva ou a solicitação de bloqueio dos números reincidentes nas instâncias de direito (como a INCM - Instituto Nacional das Comunicações de Moçambique), certifique-se de anexar as evidências e exportar os relatórios das queixas em formato CSV.
                        </p>
                    </div>

                </div>

            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-black text-white text-opacity-50 py-4 border-top">
        <div class="container text-center text-md-start small d-flex flex-column flex-md-row justify-content-between">
            <span>SDB-MZ Painel Administrativo de Controlo &copy; 2026.</span>
            <span>Segurança garantida através de credenciais criptografadas por hashing Bcrypt.</span>
        </div>
    </footer>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
