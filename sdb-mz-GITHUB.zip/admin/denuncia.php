<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Painel Administrativo - Detalhes da Denúncia (admin/denuncia.php)
 */

require_once '../includes/config.php';
require_once '../includes/functions.php';

// Garantir que utilizador está de facto autenticado como Admin
verificarAutenticacao();

$id_denuncia = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id_denuncia) {
    header("Location: index.php");
    exit();
}

$erro_mensagem = null;
$sucesso_mensagem = null;

// 1. AÇÃO: EXCLUIR RECLAMAÇÃO INDIVIDUAL
if (isset($_POST['action']) && $_POST['action'] === 'excluir') {
    try {
        // Primeiro obter arquivos anexados para excluir fisicamente do servidor
        $stmt_evid = $pdo->prepare("SELECT caminho FROM evidencias WHERE denuncia_id = ?");
        $stmt_evid->execute([$id_denuncia]);
        $anexos = $stmt_evid->fetchAll();
        
        foreach ($anexos as $anexo) {
            if (file_exists('../' . $anexo['caminho'])) {
                @unlink('../' . $anexo['caminho']); // Apagar fisicamente o ficheiro
            }
        }
        
        // Excluir do banco (com cascata configurada em setup.sql)
        $stmt_del = $pdo->prepare("DELETE FROM denuncias WHERE id = ?");
        $stmt_del->execute([$id_denuncia]);
        
        header("Location: index.php?delete_ok=1");
        exit();
    } catch (PDOException $e) {
        $erro_mensagem = "Ocorreu um erro ao excluir a denúncia: " . $e->getMessage();
    }
}

// 2. AÇÃO: ATUALIZAR ESTADO DA RECLAMAÇÃO (MUTATION)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['novo_estado'])) {
    $novo_estado = filter_input(INPUT_POST, 'novo_estado', FILTER_DEFAULT);
    $estados_permitidos = ['Em Análise', 'Confirmada', 'Em Investigação', 'Resolvida', 'Rejeitada'];
    
    if (!in_array($novo_estado, $estados_permitidos)) {
        $erro_mensagem = "Seleção de estado inválida.";
    } else {
        try {
            $stmt_update = $pdo->prepare("UPDATE denuncias SET estado = ? WHERE id = ?");
            $stmt_update->execute([$novo_estado, $id_denuncia]);
            $sucesso_mensagem = "O estado da denúncia foi atualizado com sucesso para '{$novo_estado}'.";
        } catch (PDOException $e) {
            $erro_mensagem = "Erro ao atualizar o estado no banco de dados.";
        }
    }
}

// 3. RECUPERAR INFORMACOES DA DENUNCIA E SEUS ANEXOS
try {
    $stmt_caso = $pdo->prepare("SELECT * FROM denuncias WHERE id = ? LIMIT 1");
    $stmt_caso->execute([$id_denuncia]);
    $denuncia = $stmt_caso->fetch();
    
    if (!$denuncia) {
        header("Location: index.php");
        exit();
    }
    
    // Anexos de evidências associadas
    $stmt_anexos = $pdo->prepare("SELECT * FROM evidencias WHERE denuncia_id = ?");
    $stmt_anexos->execute([$id_denuncia]);
    $evidencias = $stmt_anexos->fetchAll();
} catch (PDOException $e) {
    die("Erro ao recuperar informações da base de dados: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-MZ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDB-MZ - Detalhes da Denúncia #<?php echo htmlspecialchars($denuncia['codigo_rastreio']); ?></title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Font Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

    <!-- Flag accent -->
    <div class="flag-ribbon"></div>

    <!-- Navigation Header -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
        <div class="container-fluid px-md-5">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="p-2 me-2 bg-moz-green text-white rounded font-weight-bold d-inline-flex align-items-center" style="height:34px">
                    <i class="fas fa-lock text-moz-yellow me-2"></i> SDB-MZ Admin
                </span>
                <span class="text-white-50 small">Detalhes do Caso</span>
            </a>
            <div>
                <a href="index.php" class="btn btn-outline-light btn-sm rounded-pill px-3"><i class="fas fa-arrow-left me-1"></i>Voltar ao Dashboard</a>
            </div>
        </div>
    </nav>

    <!-- Main Container -->
    <main class="py-5">
        <div class="container">
            
            <!-- Breadcrumbs -->
            <div class="mb-4">
                <a href="index.php" class="text-decoration-none text-muted"><i class="fas fa-arrow-left me-2"></i>Voltar para o Dashboard de Denúncias</a>
            </div>

            <!-- Feedback Alertas -->
            <?php if ($erro_mensagem): ?>
                <div class="alert alert-danger border-0 p-3 mb-4 rounded-3 shadow-sm d-flex align-items-center">
                    <i class="fas fa-times-circle text-danger me-3 fa-lg"></i>
                    <div><?php echo htmlspecialchars($erro_mensagem); ?></div>
                </div>
            <?php endif; ?>

            <?php if ($sucesso_mensagem): ?>
                <div class="alert alert-success border-0 p-3 mb-4 rounded-3 shadow-sm d-flex align-items-center">
                    <i class="fas fa-check-circle text-success me-3 fa-lg"></i>
                    <div><?php echo htmlspecialchars($sucesso_mensagem); ?></div>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                
                <!-- Coluna Esquerda: Cartão Completo com Informações (Col 8) -->
                <div class="col-lg-8">
                    
                    <div class="card admin-card border-0 bg-white p-4 p-md-5 mb-4 shadow-sm">
                        
                        <!-- Header do Caso -->
                        <div class="d-flex flex-column flex-sm-row justify-content-between align-items-start align-items-sm-center border-bottom pb-4 mb-4 gap-2">
                            <div>
                                <span class="text-muted font-monospace small">CÓDIGO DE RASTREIO</span>
                                <h3 class="fw-bold text-dark font-monospace mb-0"><?php echo htmlspecialchars($denuncia['codigo_rastreio']); ?></h3>
                            </div>
                            <div class="mt-2 mt-sm-0">
                                <span class="text-muted small d-block mb-1 text-sm-end">ESTADO ATUAL</span>
                                <span class="badge <?php echo obterClasseEstado($denuncia['estado']); ?> py-2 px-3 rounded-pill fw-bold fs-6">
                                    <?php echo htmlspecialchars($denuncia['estado']); ?>
                                </span>
                            </div>
                        </div>

                        <!-- Detalhes em Tabela -->
                        <h6 class="fw-bold text-dark mb-3"><i class="fas fa-file-invoice me-2 text-moz-green"></i> Ficha Informativa do Incidente</h6>
                        <div class="table-responsive mb-4">
                            <table class="table table-bordered bg-light align-middle">
                                <tbody>
                                    <tr>
                                        <th class="w-33 bg-light-gray small text-uppercase py-3 px-3">Tipo de Incidente</th>
                                        <td class="py-3 px-3 fw-bold"><?php echo htmlspecialchars($denuncia['tipo_burla']); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Data da Ocorrência</th>
                                        <td class="py-3 px-3"><?php echo date('d/m/Y', strtotime($denuncia['data_incidente'])); ?></td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Número de Telefone Suspeito</th>
                                        <td class="py-3 px-3 font-monospace fw-bold text-danger">
                                            <?php echo $denuncia['numero_suspeito'] ? htmlspecialchars($denuncia['numero_suspeito']) : '<span class="text-muted fw-normal">Nenhum fornecido</span>'; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Valor Perdido</th>
                                        <td class="py-3 px-3 font-monospace fw-bold text-success">
                                            <?php echo formatarMeticais($denuncia['valor_envolvido']); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Email de Contrato (Anónimo)</th>
                                        <td class="py-3 px-3 font-monospace">
                                            <?php echo $denuncia['email_denunciante'] ? htmlspecialchars($denuncia['email_denunciante']) : '<span class="text-muted fw-normal"><i class="fas fa-user-secret me-1"></i> Anónimo Absoluto</span>'; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Endereço IP e Origem</th>
                                        <td class="py-3 px-3 font-monospace text-muted small">
                                            <?php echo htmlspecialchars($denuncia['ip_origem'] ?: '127.0.0.1'); ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="bg-light-gray small text-uppercase py-3 px-3">Formulário Criado Em</th>
                                        <td class="py-3 px-3 text-muted"><?php echo date('d/m/Y H:i:s', strtotime($denuncia['data_criacao'])); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Descrição Detalhada textual -->
                        <div class="mb-4">
                            <h6 class="fw-bold text-dark mb-2"><i class="fas fa-align-left me-2 text-primary"></i> Relato Detalhado do Reclamante</h6>
                            <div class="p-3 bg-light border rounded text-dark pre-wrap" style="white-space: pre-wrap; line-height: 1.7;">
                                <?php echo htmlspecialchars($denuncia['descricao']); ?>
                            </div>
                        </div>

                        <!-- Evidências Anexas -->
                        <div>
                            <h6 class="fw-bold text-dark mb-3"><i class="fas fa-paperclip me-2 text-warning"></i> Provas Documentais Carregadas</h6>
                            <?php if (empty($evidencias)): ?>
                                <div class="p-4 bg-light text-center text-muted border border-dashed rounded-3">
                                    <i class="far fa-file-archive fa-2x mb-2 text-black-50"></i>
                                    <p class="small mb-0">Nenhum ficheiro anexo / screenshot foi carregado por esta testemunha.</p>
                                </div>
                            <?php else: ?>
                                <div class="row g-3">
                                    <?php foreach ($evidencias as $anexo): ?>
                                        <div class="col-sm-6">
                                            <div class="card p-3 bg-light border h-100 d-flex flex-column justify-content-between">
                                                <div class="mb-3">
                                                    <div class="d-flex align-items-center mb-2">
                                                        <span class="p-2 bg-white rounded border me-2">
                                                            <?php if (str_starts_with($anexo['tipo'], 'image/')): ?>
                                                                <i class="far fa-file-image fa-lg text-primary"></i>
                                                            <?php else: ?>
                                                                <i class="far fa-file-pdf fa-lg text-danger"></i>
                                                            <?php endif; ?>
                                                        </span>
                                                        <div class="text-truncate">
                                                            <strong class="small d-block text-truncate text-dark" title="<?php echo htmlspecialchars($anexo['nome_ficheiro']); ?>">
                                                                <?php echo htmlspecialchars($anexo['nome_ficheiro']); ?>
                                                            </strong>
                                                            <span class="tiny text-muted font-monospace" style="font-size: 0.7rem;"><?php echo htmlspecialchars($anexo['tipo']); ?></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- Link de download seguro -->
                                                <div class="d-grid">
                                                    <a href="../<?php echo htmlspecialchars($anexo['caminho']); ?>" target="_blank" class="btn btn-sm btn-outline-dark fw-bold">
                                                        <i class="fas fa-download me-2"></i>Ver / Baixar Ficheiro
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                    </div>

                </div>

                <!-- Coluna Direita: Caixa de Controlo Administrativa (Col 4) -->
                <div class="col-lg-4">
                    
                    <!-- Cartão de Alteração de Estado de Investigação -->
                    <div class="card admin-card border-0 bg-white p-4 shadow-sm mb-4">
                        <h6 class="fw-bold text-dark mb-3"><i class="fas fa-toggle-on me-2 text-success"></i> Estado do Processo</h6>
                        <p class="text-muted small">Altere o estado do processo eletrónico. Esta modificação reflete-se de imediato na consulta pública do cidadão.</p>
                        
                        <form method="POST" action="denuncia.php?id=<?php echo (int)$id_denuncia; ?>">
                            <div class="mb-3">
                                <label for="novo_estado" class="form-label small fw-bold text-dark">Selecionar Novo Estado</label>
                                <select class="form-select" id="novo_estado" name="novo_estado" required>
                                    <option value="Em Análise" <?php echo $denuncia['estado'] == 'Em Análise' ? 'selected' : ''; ?>>Em Análise</option>
                                    <option value="Confirmada" <?php echo $denuncia['estado'] == 'Confirmada' ? 'selected' : ''; ?>>Confirmada (Fraude Ativa)</option>
                                    <option value="Em Investigação" <?php echo $denuncia['estado'] == 'Em Investigação' ? 'selected' : ''; ?>>Em Investigação (SERNIC)</option>
                                    <option value="Resolvida" <?php echo $denuncia['estado'] == 'Resolvida' ? 'selected' : ''; ?>>Resolvida (Bloqueado/Encerrado)</option>
                                    <option value="Rejeitada" <?php echo $denuncia['estado'] == 'Rejeitada' ? 'selected' : ''; ?>>Rejeitada / Inválida</option>
                                </select>
                            </div>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-success bg-moz-green text-white border-0 fw-bold py-2 shadow-sm">
                                    <i class="fas fa-save me-2 text-moz-yellow"></i> GRAVAR ESTADO
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Cartão de Ações de Exclusão Física -->
                    <div class="card admin-card border-0 bg-white p-4 shadow-sm">
                        <h6 class="fw-bold text-dark mb-3"><i class="fas fa-trash-alt me-2 text-danger"></i> Ações Críticas</h6>
                        <p class="text-muted small">Exclua permanentemente os registos e capturas anexas nas bases de dados caso sejam identificados como lixo/falsidades.</p>
                        
                        <form method="POST" action="denuncia.php?id=<?php echo (int)$id_denuncia; ?>" id="formExcluirDenuncia">
                            <input type="hidden" name="action" value="excluir">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-danger confirm-delete fw-bold py-2 shadow-sm">
                                    <i class="fas fa-exclamation-triangle me-2"></i> EXCLUIR DO APARELHO
                                </button>
                            </div>
                        </form>
                    </div>

                </div>

            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-black text-white text-opacity-50 py-4 border-top">
        <div class="container text-center small">
            SDB-MZ Painel de Detalhes Administrativos &copy; 2026. Processado de forma criptografada legal.
        </div>
    </footer>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
