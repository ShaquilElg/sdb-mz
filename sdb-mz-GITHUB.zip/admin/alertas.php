<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Painel Administrativo - Gestão de Alertas Públicos (admin/alertas.php)
 */

require_once '../includes/config.php';
require_once '../includes/functions.php';

// Garantir que utilizador está de facto autenticado como Admin
verificarAutenticacao();

$erro_mensagem = null;
$sucesso_mensagem = null;

// 1. PROCESSAR ADIÇÃO DE NOVO ALERTA
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'adicionar') {
    $titulo = filter_input(INPUT_POST, 'titulo', FILTER_DEFAULT);
    $descricao = filter_input(INPUT_POST, 'descricao', FILTER_DEFAULT);
    $tipo = filter_input(INPUT_POST, 'tipo', FILTER_DEFAULT);
    
    if (empty($titulo) || empty($descricao) || empty($tipo)) {
        $erro_mensagem = "Por favor, preencha todos os campos obrigatórios do novo alerta.";
    } else {
        try {
            $stmt_add = $pdo->prepare("INSERT INTO alertas (titulo, descricao, tipo, ativo) VALUES (?, ?, ?, 1)");
            $stmt_add->execute([$titulo, $descricao, $tipo]);
            $sucesso_mensagem = "Novo alerta público cadastrado e publicado com sucesso!";
        } catch (PDOException $e) {
            $erro_mensagem = "Ocorreu um erro ao inserir o alerta na base de dados.";
        }
    }
}

// 2. PROCESSAR ALTERAÇÃO DE ESTADO ATIVO (TOGGLE)
if (isset($_GET['action']) && $_GET['action'] === 'toggle' && isset($_GET['id'])) {
    $id_alerta = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $novo_estado = isset($_GET['curr']) && $_GET['curr'] == '1' ? 0 : 1;
    
    if ($id_alerta) {
        try {
            $stmt_tog = $pdo->prepare("UPDATE alertas SET ativo = ? WHERE id = ?");
            $stmt_tog->execute([$novo_estado, $id_alerta]);
            $sucesso_mensagem = "O estado de ativação do alerta foi atualizado.";
        } catch (PDOException $e) {
            $erro_mensagem = "Erro ao alternar o estado do alerta no banco de dados.";
        }
    }
}

// 3. PROCESSAR EXCLUSÃO DE ALERTA
if (isset($_GET['action']) && $_GET['action'] === 'deletar' && isset($_GET['id'])) {
    $id_alerta = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    
    if ($id_alerta) {
        try {
            $stmt_del = $pdo->prepare("DELETE FROM alertas WHERE id = ?");
            $stmt_del->execute([$id_alerta]);
            $sucesso_mensagem = "O alerta público foi permanentemente excluído.";
        } catch (PDOException $e) {
            $erro_mensagem = "Erro ao apagar o alerta físico.";
        }
    }
}

// 4. RECUPERAR LISTA DE TODOS OS ALERTAS ATUAIS
try {
    $stmt_alertas = $pdo->query("SELECT * FROM alertas ORDER BY data_criacao DESC");
    $todos_alertas = $stmt_alertas->fetchAll();
} catch (PDOException $e) {
    $todos_alertas = [];
}
?>
<!DOCTYPE html>
<html lang="pt-MZ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDB-MZ - Gestão de Alertas Públicos</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Font Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

    <!-- Flag accent -->
    <div class="flag-ribbon"></div>

    <!-- Admin Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark py-3">
        <div class="container-fluid px-md-5">
            <a class="navbar-brand d-flex align-items-center" href="index.php">
                <span class="p-2 me-2 bg-moz-green text-white rounded font-weight-bold d-inline-flex align-items-center" style="height:34px">
                    <i class="fas fa-lock text-moz-yellow me-2"></i> SDB-MZ Admin
                </span>
                <span class="text-white-50 small">Gestão de Alertas</span>
            </a>
            
            <div class="d-flex align-items-center gap-3">
                <span class="text-white-50 d-none d-md-inline small"><i class="far fa-user me-1 text-moz-yellow"></i> <strong><?php echo htmlspecialchars($_SESSION['admin_nome']); ?></strong></span>
                <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-pill px-3"><i class="fas fa-sign-out-alt me-1"></i>Sair</a>
            </div>
        </div>
    </nav>

    <!-- Sub Navbar Tab Selector -->
    <div class="bg-white border-bottom shadow-sm">
        <div class="container-fluid px-md-5 py-2 d-flex flex-wrap justify-content-between align-items-center">
            <div class="d-flex gap-2">
                <a href="index.php" class="btn btn-outline-dark btn-sm rounded px-3"><i class="fas fa-chart-line me-2"></i>Dashboard Geral</a>
                <a href="alertas.php" class="btn btn-dark btn-sm rounded px-3 active"><i class="fas fa-bullhorn me-2 text-moz-yellow"></i>Gerir Alertas Públicos</a>
                <a href="../index.php" target="_blank" class="btn btn-link btn-sm text-decoration-none text-muted"><i class="fas fa-external-link-alt me-1"></i>Ver Portal Público</a>
            </div>
            <div class="mt-2 mt-md-0">
                <span class="badge bg-danger rounded-pill py-2 px-3 fw-bold"><i class="fas fa-broadcast-tower me-2"></i>ALERTA CENTRAL EMITE LIVE</span>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="py-5">
        <div class="container-fluid px-md-5">

            <!-- Alertas de Sucesso / Erro -->
            <?php if ($erro_mensagem): ?>
                <div class="alert alert-danger border-0 p-3 mb-4 rounded-3 shadow-sm d-flex align-items-center">
                    <i class="fas fa-times-circle text-danger me-3 fa-lg"></i>
                    <div><?php echo htmlspecialchars($erro_mensagem); ?></div>
                </div>
            <?php endif; ?>

            <?php if ($sucesso_mensagem): ?>
                <div class="alert alert-success border-0 p-3 mb-4 rounded-3 shadow-sm d-flex align-items-center">
                    <i class="fas fa-check-circle text-success me-3 fa-lg"></i>
                    <div><?php echo htmlspecialchars($sucesso_mensagem); ?></div>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                
                <!-- Coluna Esquerda: Listagem de Alertas Cadastrados (Col 7) -->
                <div class="col-lg-7">
                    <div class="card admin-card border-0 bg-white p-4 shadow-sm h-100">
                        <h5 class="fw-bold mb-4 text-dark"><i class="fas fa-comments-alt text-moz-green me-2"></i>Alertas e Fraudes Atualmente Exibidos</h5>
                        
                        <div class="table-responsive">
                            <table class="table table-hover align-middle border">
                                <thead class="table-dark">
                                    <tr class="small text-uppercase">
                                        <th class="py-3 px-3">Tipo</th>
                                        <th class="py-3">Título do Alerta</th>
                                        <th class="py-3">Data Publicação</th>
                                        <th class="py-3 text-center">Estado</th>
                                        <th class="py-3 text-center">Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($todos_alertas)): ?>
                                        <tr>
                                            <td colspan="5" class="text-center py-5 text-muted">
                                                <i class="fas fa-bullhorn fa-3x mb-3 d-block text-black-50"></i>
                                                Nenhum alerta cadastrado de momento. Use o formulário à direita.
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($todos_alertas as $alert): ?>
                                            <tr class="small">
                                                <td class="px-3">
                                                    <span class="badge <?php echo $alert['tipo'] === 'Alerta' ? 'bg-danger text-white' : 'bg-warning text-dark'; ?> px-2 py-1">
                                                        <?php echo htmlspecialchars($alert['tipo']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <strong class="d-block text-dark"><?php echo htmlspecialchars($alert['titulo']); ?></strong>
                                                    <span class="text-muted d-block text-truncate" style="max-width:300px; font-size:0.8rem" title="<?php echo htmlspecialchars($alert['descricao']); ?>"><?php echo htmlspecialchars($alert['descricao']); ?></span>
                                                </td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($alert['data_criacao'])); ?></td>
                                                <td class="text-center">
                                                    <a href="alertas.php?action=toggle&id=<?php echo (int)$alert['id']; ?>&curr=<?php echo (int)$alert['ativo']; ?>" 
                                                       class="btn btn-sm <?php echo $alert['ativo'] ? 'btn-success bg-success' : 'btn-secondary'; ?> rounded-pill px-3 py-1 fw-bold fs-7" 
                                                       title="Clique para Ativar / Desativar">
                                                        <?php echo $alert['ativo'] ? 'Visível' : 'Oculto'; ?>
                                                    </a>
                                                </td>
                                                <td class="text-center">
                                                    <a href="alertas.php?action=deletar&id=<?php echo (int)$alert['id']; ?>" 
                                                       class="btn btn-outline-danger btn-sm rounded-circle confirm-delete" 
                                                       title="Apagar permanentemente" 
                                                       style="width: 30px; height: 30px; padding: 0; line-height: 28px;">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Coluna Direita: Formulário de Adição de Alerta (Col 5) -->
                <div class="col-lg-5">
                    <div class="card admin-card border-0 bg-white p-4 shadow-sm h-100">
                        <h5 class="fw-bold mb-4 text-dark"><i class="fas fa-plus-circle text-primary me-2"></i>Emitir Novo Alerta Público</h5>
                        <p class="text-muted small">Preencha os campos abaixo de maneira simples para fazer o alerta aparecer de forma instantânea na landing page original.</p>
                        
                        <form method="POST" action="alertas.php">
                            <input type="hidden" name="action" value="adicionar">
                            
                            <!-- Tipo de Alerta -->
                            <div class="mb-3">
                                <label for="tipo" class="form-label small fw-bold">Tipo de Emissão <span class="text-danger">*</span></label>
                                <select class="form-select" id="tipo" name="tipo" required>
                                    <option value="Alerta" selected>Alerta (SMS / Chamadas Falsas)</option>
                                    <option value="Website Falso">Website Falso (Phishing)</option>
                                    <option value="Número Suspeito">Número de burlão recorrente</option>
                                </select>
                            </div>

                            <!-- Título -->
                            <div class="mb-3">
                                <label for="titulo" class="form-label small fw-bold">Título Resumido <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="titulo" name="titulo" placeholder="ex: Cuidado com sms prémio Vodacom" required>
                            </div>

                            <!-- Descrição -->
                            <div class="mb-4">
                                <label for="descricao" class="form-label small fw-bold">Mensagem e Recomendações <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="descricao" name="descricao" rows="5" placeholder="Descrição clara e recomendações para o cidadão comum de Moçambique." required></textarea>
                            </div>

                            <!-- Submit -->
                            <div class="d-grid mb-3">
                                <button type="submit" class="btn btn-success bg-moz-green text-white border-0 fw-bold py-3 shadow-sm">
                                    <i class="fas fa-bullhorn me-2 text-moz-yellow"></i>DIVULGAR E EMITIR ALERTA
                                </button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-black text-white text-opacity-50 py-4 border-top">
        <div class="container text-center small">
            SDB-MZ Centro de Gestão de Alertas Coletivos &copy; 2026.
        </div>
    </footer>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="../assets/js/main.js"></script>
</body>
</html>
