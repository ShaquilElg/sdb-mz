<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Ecrã de Login Administrativo (admin/login.php)
 */

require_once '../includes/config.php';
require_once '../includes/functions.php';

$erro_mensagem = null;

// Redirecionar se já logado
if (isset($_SESSION['admin_logged']) && $_SESSION['admin_logged'] === true) {
    header("Location: index.php");
    exit();
}

// Tratar submissão de login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'] ?? '';
    
    if (empty($email) || empty($password)) {
        $erro_mensagem = "Por favor, insira o seu e-mail corporativo e palavra-passe.";
    } else {
        try {
            $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $admin = $stmt->fetch();
            
            if ($admin && password_verify($password, $admin['password_hash'])) {
                // Login com Sucesso
                $_SESSION['admin_logged'] = true;
                $_SESSION['admin_id'] = $admin['id'];
                $_SESSION['admin_nome'] = $admin['nome'];
                $_SESSION['admin_email'] = $admin['email'];
                $_SESSION['ultima_atividade'] = time(); // Para controlar expiração
                
                header("Location: index.php");
                exit();
            } else {
                $erro_mensagem = "Credenciais de administrador inválidas ou não autorizadas no sistema.";
            }
        } catch (PDOException $e) {
            $erro_mensagem = "Erro interno de banco de dados ao autenticar administrador.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-MZ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDB-MZ - Login Administrativo</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Font Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-dark" style="background-color: #121816 !important;">

    <div class="flag-ribbon"></div>

    <div class="container d-flex flex-column justify-content-center min-vh-100 py-5">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                
                <!-- Logo brand -->
                <div class="text-center mb-4">
                    <a href="../index.php" class="text-decoration-none d-inline-block">
                        <span class="p-3 bg-moz-green text-white rounded font-weight-bold d-inline-flex align-items-center mb-2 fs-4" style="box-shadow: 0 4px 10px rgba(0, 154, 68, 0.4);">
                            <i class="fas fa-lock me-2 text-moz-yellow"></i> SDB-MZ
                        </span>
                    </a>
                    <h5 class="text-white fw-bold mb-1">Painel Administrativo</h5>
                    <p class="text-white-50 small">Acesso restrito a analistas e autoridades do SDB-MZ.</p>
                </div>

                <!-- Login Card -->
                <div class="card border-0 rounded-4 shadow p-4 bg-white">
                    
                    <?php if (isset($_GET['erro']) && $_GET['erro'] === 'sessao_expirada'): ?>
                        <div class="alert alert-warning text-center small py-2 border-0 rounded mb-3">
                            <i class="fas fa-hourglass-end me-2"></i> Sessão expirada por inatividade. Faça login novamente.
                        </div>
                    <?php endif; ?>

                    <?php if ($erro_mensagem): ?>
                        <div class="alert alert-danger text-center small py-2 border-0 rounded mb-3">
                            <i class="fas fa-exclamation-triangle me-2"></i> <?php echo htmlspecialchars($erro_mensagem); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="login.php">
                        
                        <!-- E-mail -->
                        <div class="mb-3">
                            <label for="email" class="form-label fw-bold text-dark small">E-mail Corporativo</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="fas fa-user-shield"></i></span>
                                <input type="email" class="form-control" id="email" name="email" placeholder="admin@sdb.co.mz" required>
                            </div>
                        </div>

                        <!-- Palavra-passe -->
                        <div class="mb-4">
                            <div class="d-flex justify-content-between">
                                <label for="password" class="form-label fw-bold text-dark small">Palavra-passe</label>
                            </div>
                            <div class="input-group">
                                <span class="input-group-text bg-light text-muted"><i class="fas fa-key"></i></span>
                                <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
                            </div>
                        </div>

                        <!-- Botão Entrar -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-success py-2 fw-bold bg-moz-green border-0"><i class="fas fa-sign-in-alt me-2 text-moz-yellow"></i>ENTRAR PAINEL</button>
                        </div>

                    </form>
                    
                </div>
                
                <!-- Demo Login Help Card -->
                <div class="card border-0 rounded-4 shadow-sm p-3 mt-4 text-white" style="background-color: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255,255,255,0.1)">
                    <h6 class="fw-bold mb-2 text-moz-yellow text-center" style="font-size:0.85rem"><i class="fas fa-info-circle me-1"></i> Credenciais Demo de Desenvolvimento:</h6>
                    <div class="small text-white-50">
                        <div class="d-flex justify-content-between mb-1">
                            <span>E-mail:</span> <strong class="text-white">admin@sdb.co.mz</strong>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Palavra-passe:</span> <strong class="text-white">admin123</strong>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="../index.php" class="text-white-50 text-decoration-none small"><i class="fas fa-arrow-left me-1"></i>Voltar ao portal público SDB-MZ</a>
                </div>

            </div>
        </div>
    </div>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
