<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Encerramento de Sessão Administrativa (admin/logout.php)
 */

require_once '../includes/config.php';

// Limpar todas as variáveis de sessão
$_SESSION = [];

// Excluir cookie de sessão se aplicável
if (ini_get("session_use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destruir Sessão Física
session_destroy();

// Redirecionar para o ecrã de login corporativo
header("Location: login.php");
exit();
