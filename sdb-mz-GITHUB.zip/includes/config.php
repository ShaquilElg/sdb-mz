<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Ficheiro de Configuração Geral e Conexão de Base de Dados (config.php)
 */

// Evitar acessos diretos se incluído incorretamente
if (basename($_SERVER['PHP_SELF']) == 'config.php') {
    die("Acesso restrito.");
}

// Configuração de Erros para Desenvolvimento (Desativar em Produção)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Servidor Base de Dados (Ajustar consoante o hosting: Localhost para XAMPP, ou host do InfinityFree/000webhost)
define('DB_HOST', 'db.zxlszqbwpojshewzhfia.supabase.co');
define('DB_NAME', 'postgres');
define('DB_USER', 'postgres');
define('DB_PASS', '@qZgN8fHSvF#h/m');
define('DB_PORT', '5432');

// Inicialização de Sessão Segura
if (session_status() === PHP_SESSION_NONE) {
    // Definir cookies seguros se em HTTPS
    $secure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
    session_set_cookie_params([
        'lifetime' => 3600, // 1 hora de validade
        'path' => '/',
        'domain' => $_SERVER['HTTP_HOST'] ?? '',
        'secure' => $secure,
        'httponly' => true, // Proteção contra roubo de sessão via JS (XSS)
        'samesite' => 'Strict'
    ]);
    session_start();
}

// Configurar Timezone padrão para Moçambique
date_default_timezone_set('Africa/Maputo');

// Conexão Segura usando PDO
try {
    $pdo = new PDO(
        "pgsql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME,
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false, // Proteção adicional contra SQL Injection
        ]
    );
} catch (PDOException $e) {
    // Em caso de falha de conexão, não expor detalhes internos ao utilizador público
    die("Erro crítico de conexão: De momento não foi possível ligar à Base de Dados. " . (error_reporting() > 0 ? $e->getMessage() : ''));
}

// Enviar cabeçalhos básicos de Segurança para mitigar ataques comuns
header("X-Frame-Options: SAMEORIGINS");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: no-referrer-when-downgrade");
