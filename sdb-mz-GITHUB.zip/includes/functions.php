<?php
/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Funções Globais de Segurança, Validação e Negócio (functions.php)
 */

if (basename($_SERVER['PHP_SELF']) == 'functions.php') {
    die("Acesso restrito.");
}

/**
 * Sanitizar outputs contra XSS (Cross Site Scripting)
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Formatar valores de Moedas em Meticais (MZN)
 */
function formatarMeticais($valor) {
    if ($valor === null || $valor === '') {
        return "N/D";
    }
    return number_format((float)$valor, 2, ',', '.') . ' MZN';
}

/**
 * Gerar um código de rastreio único para a denúncia (SDB-ANO-RAN5)
 * Ex: SDB-2026-R8F2B
 */
function gerarCodigoRastreio($pdo) {
    $anoCurrent = date('Y');
    $caracteres = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $codigo_gerado = '';
    
    // Tenta gerar um código único e confirma na Base de Dados se não há colisão
    $tentativas = 0;
    while ($tentativas < 10) {
        $rand_str = '';
        for ($i = 0; $i < 5; $i++) {
            $rand_str .= $caracteres[random_int(0, strlen($caracteres) - 1)];
        }
        $codigo_gerado = "SDB-{$anoCurrent}-{$rand_str}";
        
        $stmt = $pdo->prepare("SELECT id FROM denuncias WHERE codigo_rastreio = ?");
        $stmt->execute([$codigo_gerado]);
        if ($stmt->rowCount() == 0) {
            return $codigo_gerado;
        }
        $tentativas++;
    }
    
    // Fallback caso extremamente improvável de colisões repetidas
    return "SDB-" . $anoCurrent . "-" . random_int(10000, 99999);
}

/**
 * Obter a badge/classe CSS correspondente ao Estado da Denúncia
 */
function obterClasseEstado($estado) {
    switch ($estado) {
        case 'Em Análise':
            return 'bg-secondary text-white';
        case 'Confirmada':
            return 'bg-warning text-dark';
        case 'Em Investigação':
            return 'bg-info text-dark';
        case 'Resolvida':
            return 'bg-success text-white';
        case 'Rejeitada':
            return 'bg-danger text-white';
        default:
            return 'bg-light text-dark';
    }
}

/**
 * Obter endereço IP real do utilizador
 */
function obterIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
    // Caso de múltiplos IPs encaminhados
    $ips = explode(',', $ip);
    return trim($ips[0]);
}

/**
 * Rate Limiting Básico (Impede mais de 3 reclamações por minuto do mesmo IP)
 */
function verificarRateLimit($pdo) {
    $ip = obterIP();
    $minuto_atras = date('Y-m-d H:i:s', strtotime('-1 minute'));
    
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM denuncias WHERE ip_origem = ? AND data_criacao >= ?");
    $stmt->execute([$ip, $minuto_atras]);
    $resultado = $stmt->fetch();
    
    if ($resultado && $resultado['total'] >= 3) {
        return false; // Bloquear
    }
    return true; // Permitido
}

/**
 * Verificar se o Administrador está iniciado de forma válida e ativa
 */
function verificarAutenticacao() {
    if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
        header("Location: login.php");
        exit();
    }
    
    // Verificar se a sessão expirou (ex: após 30 minutos de inatividade)
    $inatividade = 1800; // 30 minutos em segundos
    if (isset($_SESSION['ultima_atividade']) && (time() - $_SESSION['ultima_atividade'] > $inatividade)) {
        session_unset();
        session_destroy();
        header("Location: login.php?erro=sessao_expirada");
        exit();
    }
    $_SESSION['ultima_atividade'] = time(); // Atualizar última atividade
}

/**
 * Obter alertas públicos recentes
 */
function obterAlertasAtivos($pdo, $limite = 5) {
    try {
        $stmt = $pdo->query("SELECT * FROM alertas WHERE ativo = 1 ORDER BY data_criacao DESC LIMIT " . (int)$limite);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Validar extensão e tipo MIME do arquivo carregado
 */
function validarUpload($ficheiro) {
    if (!isset($ficheiro) || $ficheiro['error'] === UPLOAD_ERR_NO_FILE) {
        return [
            'valido' => true,
            'erro' => null,
            'no_file' => true
        ];
    }
    
    if ($ficheiro['error'] !== UPLOAD_ERR_OK) {
        return [
            'valido' => false,
            'erro' => 'Ocorreu um erro ao carregar o ficheiro. Código: ' . $ficheiro['error'],
            'no_file' => false
        ];
    }
    
    // Limite de tamanho: 5MB
    $max_tamanho = 5 * 1024 * 1024; // 5 Megabytes
    if ($ficheiro['size'] > $max_tamanho) {
        return [
            'valido' => false,
            'erro' => 'O ficheiro excede o tamanho máximo permitido de 5MB.',
            'no_file' => false
        ];
    }
    
    // Tipo MIME Permitidos (Imagens e PDF)
    $mime_permitidos = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'application/pdf'
    ];
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_real = finfo_file($finfo, $ficheiro['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_real, $mime_permitidos)) {
        return [
            'valido' => false,
            'erro' => 'Tipo de ficheiro inválido. Apenas imagens (JPG, PNG, GIF, WEBP) e PDFs são permitidos.',
            'no_file' => false
        ];
    }
    
    // Extensões correspondentes
    $extensao = strtolower(pathinfo($ficheiro['name'], PATHINFO_EXTENSION));
    $extensoes_permitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
    if (!in_array($extensao, $extensoes_permitidas)) {
        return [
            'valido' => false,
            'erro' => 'Formato do ficheiro inconsistente.',
            'no_file' => false
        ];
    }
    
    return [
        'valido' => true,
        'erro' => null,
        'no_file' => false,
        'extensao' => $extensao,
        'tipo' => $mime_real
    ];
}
