/**
 * SDB-MZ (Sistema de Denúncia de Burlas de Moçambique)
 * Scripts Frontend (main.js)
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Copiar Código de Rastreio para a Área de Transferência
    const copyBtn = document.getElementById('btnCopiarRastreio');
    if (copyBtn) {
        copyBtn.addEventListener('click', function() {
            const codeSpan = document.getElementById('codigoRastreio');
            if (codeSpan) {
                const text = codeSpan.textContent || codeSpan.innerText;
                navigator.clipboard.writeText(text.trim()).then(function() {
                    // Feedback visual temporário
                    const originalHTML = copyBtn.innerHTML;
                    copyBtn.innerHTML = '<i class="fas fa-check me-2"></i>Copiado!';
                    copyBtn.classList.remove('btn-outline-primary', 'btn-outline-dark');
                    copyBtn.classList.add('btn-success');
                    
                    setTimeout(function() {
                        copyBtn.innerHTML = originalHTML;
                        copyBtn.classList.remove('btn-success');
                        copyBtn.classList.add('btn-outline-dark');
                    }, 2000);
                }).catch(function(err) {
                    console.error('Erro ao copiar código: ', err);
                });
            }
        });
    }

    // 2. Validação de Ficheiro no Sandbox do Utilizador (Máx 5MB + Extensões permitidas)
    const fileInput = document.getElementById('evidencias');
    const fileFeedback = document.getElementById('ficheiroFeedback');
    
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length > 0) {
                const file = fileInput.files[0];
                const maxSize = 5 * 1024 * 1024; // 5MB
                const extension = file.name.split('.').pop().toLowerCase();
                const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf'];
                
                let hasError = false;
                let errorMsg = '';
                
                if (file.size > maxSize) {
                    hasError = true;
                    errorMsg = 'O ficheiro selecionado excede o limite máximo permitido de 5MB.';
                } else if (!allowedExtensions.includes(extension)) {
                    hasError = true;
                    errorMsg = 'Extensão inválida. Carregue apenas ficheiros de imagem ou PDFs.';
                }
                
                if (hasError) {
                    fileInput.value = ''; // Limpar input
                    if (fileFeedback) {
                        fileFeedback.className = 'text-danger mt-1 small';
                        fileFeedback.innerHTML = '<i class="fas fa-times-circle me-1"></i>' + errorMsg;
                    } else {
                        alert(errorMsg);
                    }
                } else {
                    if (fileFeedback) {
                        fileFeedback.className = 'text-success mt-1 small';
                        const sizeMB = (file.size / (1024 * 1024)).toFixed(2);
                        fileFeedback.innerHTML = `<i class="fas fa-check-circle me-1"></i> Ficheiro pronto (${sizeMB} MB) - Extensão: .${extension.toUpperCase()}`;
                    }
                }
            } else {
                if (fileFeedback) {
                    fileFeedback.innerHTML = '';
                }
            }
        });
    }

    // 3. Validação do Termo de Verdade no Formulário de Denúncia
    const formDenuncia = document.getElementById('formDenuncia');
    if (formDenuncia) {
        formDenuncia.addEventListener('submit', function(e) {
            const checkboxVerdade = document.getElementById('confirma_verdade');
            if (checkboxVerdade && !checkboxVerdade.checked) {
                e.preventDefault();
                alert('Deve confirmar as declarações do formulário como autênticas antes de submeter.');
            }
        });
    }
    
    // 4. Confirmar exclusão de Alertas / Denúncias nos ecrãs de Admin
    const btnsConfirm = document.querySelectorAll('.confirm-delete');
    btnsConfirm.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            if (!confirm('Tem a certeza absoluta de que quer excluir este registo? Esta ação é irreversível.')) {
                e.preventDefault();
            }
        });
    });
});
